using System;
using System.Threading.Tasks;
using Catalog.Api.Entities;
using System.Collections.Generic;

namespace Catalog.Api.Repositories
{

    public interface IItemsRepository
    {
        Task<Item> GetItemAsync(Guid id);
        Task<IEnumerable<Item>> GetItemsAsync();
        Task CreatedItemAsync(Item item);
        Task UpdateItemAsync(Item item);
        Task DeleteItemAsync(Guid id);
    }

}